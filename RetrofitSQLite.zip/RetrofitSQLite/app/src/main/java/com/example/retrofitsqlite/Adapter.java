package com.example.retrofitsqlite;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Adapter extends RecyclerView.Adapter<Adapter._ViewHolder> {

    private ArrayList<Post> itemsList;

    public static class _ViewHolder extends RecyclerView.ViewHolder{

        public TextView id;
        public TextView userID;
        public TextView title;
        public TextView text;

        public _ViewHolder(@NonNull View itemView) {
            super(itemView);
            id = itemView.findViewById(R.id.ID);
            userID = itemView.findViewById(R.id.UserID);
            title = itemView.findViewById(R.id.Title);
            text = itemView.findViewById(R.id.Body);
        }
    }

    public Adapter(ArrayList<Post> itemsList){
        this.itemsList = itemsList;
    }

    @NonNull
    @Override
    public _ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_view, parent, false);
        _ViewHolder viewHolder = new _ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull _ViewHolder holder, int position) {
        Post post = itemsList.get(position);

        holder.id.setText("ID: "+String.valueOf(post.getId()));
        holder.userID.setText("UserID: "+String.valueOf(post.getUserId()));
        holder.title.setText("Title: "+post.getTitle());
        holder.text.setText("Body: "+post.getText());
    }

    //@Override
    //public void onBindViewHolder(@NonNull Adapter holder, int position) {

    //}

  //  @Override
  //  public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

  //  }

    @Override
    public int getItemCount() {
        return itemsList.size();
    }
}
