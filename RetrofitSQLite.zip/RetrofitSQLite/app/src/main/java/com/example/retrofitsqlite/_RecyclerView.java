package com.example.retrofitsqlite;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class _RecyclerView extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Post> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);
        arrayList = new ArrayList<Post>();

        Bundle bundle = getIntent().getExtras();
        arrayList = (ArrayList<Post>) bundle.getSerializable("postList");
        //int tt = 7;
        //String vb = "jjj";
        //DatabaseHelper db = (DatabaseHelper) bundle.getParcelable("Database");

        //Cursor cursor = db.ReadData();
        //cursor.getString(0);
        //arrayList.add(new Post(456, 789, "Title2", "Text2"));
        //arrayList.add(new Post(1,Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2)));

        recyclerView = findViewById(R.id.recyclerView);

        layoutManager = new LinearLayoutManager(this);

        adapter = new Adapter(arrayList);

        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(adapter);
    }
}
