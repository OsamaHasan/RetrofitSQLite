package com.example.retrofitsqlite;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Post> posts;
    private Button next;
    private ArrayList<Post> arrayList;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        next = findViewById(R.id.next);
        arrayList = new ArrayList<Post>();

        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create()).build();

        JsonPlaceholderApi jsonPlaceholderApi = retrofit.create(JsonPlaceholderApi.class);

        Call<List<Post>> call = jsonPlaceholderApi.getPosts();

        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (!response.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Error: "+response.code(), Toast.LENGTH_LONG).show();
                    return;
                }

                posts = response.body();

                for (Post post : posts){
                    db.insertData(post.getUserId(), post.getTitle(), post.getText());
                }
                //db.insertData(123, "Title", "Text is Next");
                Cursor cursor = db.ReadData();
                if (cursor.getCount() != 0){
                    while (cursor.moveToNext()){
                        arrayList.add(new Post(
                                Integer.parseInt(cursor.getString(0)),
                                Integer.parseInt(cursor.getString(1)),
                                cursor.getString(2),
                                cursor.getString(3)
                        ));
                    }
                }

                    //arrayList.add(new Post(post.getId(),post.getUserId(),post.getTitle(),post.getText()));
                //arrayList.add(new Post(cursor.getInt(0),cursor.getInt(1),cursor.getString(2),cursor.getString(3)));
                //arrayList.add(new Post(456, 789, "Title2", "Text2"));
                //arrayList.add(new Post(456, 789, "Title2", "Text2"));
                //arrayList.add(new Post(456, 789, "Title2", "Text2"));
                //}
                db.close();
                if (!posts.isEmpty()) {
                    next.setText("Go!");
                }

            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Error: "+t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    public void toRecyclerView(View view) {
        Intent intent = new Intent(MainActivity.this, _RecyclerView.class);
        Bundle bundle = new Bundle();
        //bundle.putParcelable("Database", db);
        bundle.putSerializable("postList", arrayList);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
